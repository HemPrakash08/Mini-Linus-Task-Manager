# ProcPulse Testing Report

## 1. Build Verification

- Compiler: GCC
- Language standard: C++17
- Build system: CMake
- Build configuration: Release

## 2. Functional Tests

| Test | Expected Result | Status |
|---|---|---|
| CPU monitoring | CPU usage updates | Pending |
| Memory monitoring | RAM metrics update | Pending |
| Disk monitoring | Disk metrics display | Pending |
| Network monitoring | Throughput updates | Pending |
| Process listing | Processes are displayed | Pending |
| Process sorting | Correct sorting order | Pending |
| Process search | Matching processes appear | Pending |
| Process termination | Selected process terminates | Pending |
| Historical graphs | Graphs update | Pending |
| Zombie detection | Zombie processes detected | Pending |
| Alert history | Alerts are recorded | Pending |
| CSV export | Valid CSV generated | Pending |
| Settings | Preferences persist | Pending |

## 3. Automated Tests

Command:

    ctest --test-dir build --output-on-failure

Tests:
- Healthy system status
- CPU warning
- CPU critical
- Memory warning
- Disk warning
- Zombie process detection
- Combined alerts

## 4. Performance and Stability

- Long-duration dashboard execution
- Terminal resizing
- Memory usage observation
- Process refresh stability
- Memory leak inspection

## 5. Environment

Operating System: Ubuntu on WSL2
Compiler: GCC
Build System: CMake
User Interface: ncurses
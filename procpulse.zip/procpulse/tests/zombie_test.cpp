#include <iostream>
#include <unistd.h>
#include <sys/wait.h>

int main() {

    pid_t pid = fork();

    if (pid == 0) {
        return 0;
    }

    std::cout << "Parent PID: " << getpid() << std::endl;
    std::cout << "Zombie child PID: " << pid << std::endl;

    sleep(20);

    waitpid(pid, nullptr, 0);

    std::cout << "Zombie cleaned up." << std::endl;

    return 0;
}
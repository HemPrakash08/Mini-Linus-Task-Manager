# ProcPulse — Advanced Linux System Monitor

ProcPulse is a terminal-based Linux system monitoring and process management application developed using C++17 and ncurses.

It provides real-time visibility into system resource utilization, running processes, performance history, network activity, disk activity and system health.

## Features

### System Monitoring
- Real-time CPU utilization.
- Logical CPU core count.
- RAM usage and availability.
- Swap information.
- System uptime.
- System load averages.
- Disk capacity and utilization.
- Disk read/write throughput.
- Network receive/transmit throughput.

### Process Management
- Process listing through the Linux `/proc` filesystem.
- PID and parent PID information.
- Process state and thread count.
- Per-process CPU utilization.
- Per-process memory utilization.
- Process sorting.
- Process search.
- Process details.
- Process termination with confirmation.

### Performance History
- CPU utilization history.
- Memory utilization history.
- Disk read/write history.
- Network download/upload history.
- Rolling 60-sample history.
- Live terminal graphs.

### System Health
- CPU usage warnings.
- Memory usage warnings.
- Disk usage warnings.
- Zombie process detection.
- Healthy, Warning and Critical status.
- Recent alert history.

### Export and Configuration
- CSV process export.
- Configurable refresh interval.
- Custom export directory.
- Persistent configuration.

## Technology Stack

| Component | Technology |
|---|---|
| Programming language | C++17 |
| User interface | ncurses |
| Build system | CMake |
| Compiler | GCC |
| Operating system interface | Linux `/proc` |
| Process management | Linux signals |
| Export format | CSV |
| Version control | Git |

## Project Structure

```text
procpulse/
├── CMakeLists.txt
├── README.md
├── include/
│   ├── process/
│   ├── system/
│   ├── ui/
│   └── utils/
├── src/
│   ├── main.cpp
│   ├── process/
│   ├── system/
│   ├── ui/
│   └── utils/
├── tests/
├── docs/
└── data/
```

## Requirements

- Linux or WSL2 with a Linux distribution.
- GCC with C++17 support.
- CMake.
- ncurses development library.
- Git.

## Installation

Install the dependencies on Ubuntu:

```bash
sudo apt update
sudo apt install build-essential cmake libncurses-dev pkg-config git
```

Clone the repository:

```bash
git clone YOUR_REPOSITORY_URL
cd procpulse
```

Build:

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j$(nproc)
```

Run:

```bash
./build/procpulse
```

## Keyboard Controls

| Key | Function |
|---|---|
| Up/Down | Select process |
| C | Sort by CPU |
| M | Sort by memory |
| P | Sort by PID |
| / | Search processes |
| A | Show all processes |
| Enter | Process details |
| K | Terminate selected process |
| G | Toggle performance graphs |
| H | Alert history |
| E | Export processes to CSV |
| S | Open settings |
| Q | Quit |

## Configuration

Configuration is stored in:

```text
~/.config/procpulse/config.conf
```

Settings include:

- Refresh interval: 500–5000 milliseconds.
- CSV export directory.

## Data Sources

ProcPulse reads Linux system information from:

- `/proc/stat` — aggregate CPU counters.
- `/proc/meminfo` — memory information.
- `/proc/uptime` — system uptime.
- `/proc/loadavg` — load averages.
- `/proc/[PID]/stat` — process information.
- `/proc/net/dev` — network counters.
- `/proc/diskstats` — disk I/O counters.

Disk capacity is obtained through the filesystem statistics interface.

## Testing

Run automated alert tests:

```bash
ctest --test-dir build --output-on-failure
```

Additional manual tests include:

- CPU load generation.
- Memory utilization comparison.
- Disk I/O generation.
- Network activity monitoring.
- Process creation and termination.
- Zombie process detection.
- CSV export validation.
- Configuration persistence.

## Limitations

- ProcPulse monitors the Linux environment in which it runs. Under WSL2, reported resources represent the Linux environment and its virtualized interfaces rather than a complete Windows host-level monitoring view.
- Performance history is held in memory and resets when the application exits.
- Process visibility and termination depend on Linux permissions.
- Resource readings can differ slightly from other monitoring utilities because of sampling intervals and measurement conventions.

## Future Enhancements

- Persistent performance history.
- Configurable alert thresholds.
- Multi-core CPU graphs.
- Process tree visualization.
- Process priority management.
- System resource logging.
- Additional automated unit and integration tests.

## License

Specify the license selected for this project before publishing or distributing it.

#ifndef DISK_HPP
#define DISK_HPP

#include <cstdint>

struct DiskStats {
    uint64_t totalBytes = 0;
    uint64_t usedBytes = 0;
    uint64_t readBytes = 0;
    uint64_t writeBytes = 0;
};

DiskStats getDiskStats();

#endif
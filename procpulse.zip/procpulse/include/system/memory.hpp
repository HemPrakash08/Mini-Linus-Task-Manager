#ifndef MEMORY_HPP
#define MEMORY_HPP

struct MemoryStats {
    double total;
    double available;
    double used;
    double usagePercent;
    double swapTotal;
    double swapFree;
};

MemoryStats getMemoryStats();

#endif
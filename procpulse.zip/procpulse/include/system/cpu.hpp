#ifndef CPU_HPP
#define CPU_HPP

#include <cstdint>

struct CPUStats {
    uint64_t total;
    uint64_t idle;
};

CPUStats getCPUStats();
double getCPUUsage(const CPUStats& previous, const CPUStats& current);
int getCPUCoreCount();

#endif
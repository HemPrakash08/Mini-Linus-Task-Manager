#ifndef SYSTEM_INFO_HPP
#define SYSTEM_INFO_HPP

#include <string>

struct SystemInfo {
    double uptime;
    double load1;
    double load5;
    double load15;
};

SystemInfo getSystemInfo();
std::string formatUptime(double seconds);

#endif
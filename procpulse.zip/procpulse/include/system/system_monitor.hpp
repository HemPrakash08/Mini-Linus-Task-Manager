#ifndef SYSTEM_MONITOR_HPP
#define SYSTEM_MONITOR_HPP

#include "system/cpu.hpp"
#include "system/memory.hpp"
#include "system/system_info.hpp"

#endif
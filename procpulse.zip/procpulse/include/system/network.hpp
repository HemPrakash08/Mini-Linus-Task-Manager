#ifndef NETWORK_HPP
#define NETWORK_HPP

#include <cstdint>

struct NetworkStats {
    uint64_t receivedBytes = 0;
    uint64_t transmittedBytes = 0;
};

NetworkStats getNetworkStats();

#endif
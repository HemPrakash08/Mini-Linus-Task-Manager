#ifndef ALERTS_HPP
#define ALERTS_HPP

#include "process/process.hpp"

#include <string>
#include <vector>

struct HealthReport {
    int zombieCount = 0;
    std::string healthStatus = "HEALTHY";
    std::vector<std::string> alerts;
};

HealthReport evaluateHealth(
    double cpuUsage,
    double memoryUsage,
    double diskUsage,
    const std::vector<ProcessInfo>& processes
);

#endif
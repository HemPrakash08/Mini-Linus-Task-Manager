#ifndef GRAPHS_HPP
#define GRAPHS_HPP

#include <string>
#include <vector>

void drawGraph(
    const std::string& title,
    const std::vector<double>& values,
    int y,
    int x,
    int width,
    int height,
    double maxValue
);

#endif
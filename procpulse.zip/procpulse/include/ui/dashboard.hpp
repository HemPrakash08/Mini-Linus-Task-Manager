#ifndef DASHBOARD_HPP
#define DASHBOARD_HPP

void runDashboard();

#endif
#ifndef PROCESS_MANAGER_HPP
#define PROCESS_MANAGER_HPP

#include "process/process.hpp"

#include <vector>
#include <unordered_map>

std::vector<ProcessInfo> getAllProcesses();

void calculateProcessUsage(
    std::vector<ProcessInfo>& current,
    const std::unordered_map<int, ProcessInfo>& previous,
    uint64_t totalCpuDiff,
    int coreCount,
    double totalMemoryKB
);

#endif
#ifndef PROCESS_HPP
#define PROCESS_HPP

#include <string>
#include <cstdint>

struct ProcessInfo {
    int pid = 0;
    int ppid = 0;

    std::string name;
    char state = '?';

    uint64_t cpuTicks = 0;

    long rssKB = 0;
    int threads = 0;

    double cpuPercent = 0.0;
    double memoryPercent = 0.0;
};

bool readProcess(int pid, ProcessInfo& process);

#endif
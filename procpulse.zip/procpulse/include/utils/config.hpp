#ifndef CONFIG_HPP
#define CONFIG_HPP

#include <string>

struct AppConfig {
    int refreshIntervalMs = 1000;
    std::string exportDirectory;
};

AppConfig loadConfig();
bool saveConfig(const AppConfig& config);

#endif
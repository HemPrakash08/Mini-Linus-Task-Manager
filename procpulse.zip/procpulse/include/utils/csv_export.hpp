#ifndef CSV_EXPORT_HPP
#define CSV_EXPORT_HPP

#include "process/process.hpp"

#include <string>
#include <vector>

bool exportProcessesCSV(
    const std::vector<ProcessInfo>& processes,
    const std::string& directory,
    std::string& outputPath,
    std::string& errorMessage
);

#endif
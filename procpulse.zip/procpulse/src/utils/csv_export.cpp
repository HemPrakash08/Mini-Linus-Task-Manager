#include "utils/csv_export.hpp"

#include <chrono>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <sstream>

namespace {

std::string escapeCSV(const std::string& value) {

    std::string result = "\"";

    for (char c : value) {

        if (c == '"') {
            result += "\"\"";
        }
        else {
            result += c;
        }
    }

    result += "\"";

    return result;
}

}

bool exportProcessesCSV(
    const std::vector<ProcessInfo>& processes,
    const std::string& directory,
    std::string& outputPath,
    std::string& errorMessage
) {

    try {

        if (directory.empty()) {
            errorMessage = "Export directory is empty.";
            return false;
        }

        std::filesystem::path folder(directory);

        std::filesystem::create_directories(folder);

        auto now = std::chrono::system_clock::now();

        std::time_t currentTime =
            std::chrono::system_clock::to_time_t(now);

        std::tm localTime{};

        if (localtime_r(&currentTime, &localTime) == nullptr) {
            errorMessage = "Unable to generate export timestamp.";
            return false;
        }

        auto milliseconds =
            std::chrono::duration_cast<std::chrono::milliseconds>(
                now.time_since_epoch()
            ).count() % 1000;

        std::ostringstream filename;

        filename << "procpulse_processes_"
                 << std::put_time(
                     &localTime,
                     "%Y%m%d_%H%M%S"
                 )
                 << "_"
                 << std::setw(3)
                 << std::setfill('0')
                 << milliseconds
                 << ".csv";

        std::filesystem::path filePath =
            folder / filename.str();

        std::ofstream file(filePath);

        if (!file.is_open()) {
            errorMessage = "Unable to create CSV file.";
            return false;
        }

        file << "PID,PPID,Process Name,State,CPU Percent,"
             << "Memory Percent,RSS KB,Threads\n";

        for (const auto& process : processes) {

            file << process.pid << ','
                 << process.ppid << ','
                 << escapeCSV(process.name) << ','
                 << process.state << ','
                 << std::fixed << std::setprecision(2)
                 << process.cpuPercent << ','
                 << process.memoryPercent << ','
                 << process.rssKB << ','
                 << process.threads << '\n';
        }

        file.close();

        if (!file) {
            errorMessage = "An error occurred while writing the CSV.";
            return false;
        }

        outputPath = filePath.string();

        return true;
    }
    catch (const std::exception& exception) {

        errorMessage = exception.what();

        return false;
    }
}
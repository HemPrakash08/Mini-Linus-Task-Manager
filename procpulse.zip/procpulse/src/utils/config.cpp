#include "utils/config.hpp"

#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <sstream>

namespace {

std::filesystem::path getConfigPath() {

    const char* home = std::getenv("HOME");

    if (home == nullptr) {
        return {};
    }

    return std::filesystem::path(home) /
           ".config" / "procpulse" / "config.conf";
}

std::string getDefaultExportDirectory() {

    const char* home = std::getenv("HOME");

    if (home == nullptr) {
        return "./procpulse_exports";
    }

    return (std::filesystem::path(home) /
            "procpulse_exports").string();
}

}

AppConfig loadConfig() {

    AppConfig config;

    config.exportDirectory = getDefaultExportDirectory();

    std::filesystem::path path = getConfigPath();

    if (path.empty()) {
        return config;
    }

    std::ifstream file(path);

    if (!file.is_open()) {
        return config;
    }

    std::string line;

    while (std::getline(file, line)) {

        size_t separator = line.find('=');

        if (separator == std::string::npos) {
            continue;
        }

        std::string key = line.substr(0, separator);
        std::string value = line.substr(separator + 1);

        if (key == "refresh_interval_ms") {

            try {
                int interval = std::stoi(value);

                if (interval >= 500 && interval <= 5000) {
                    config.refreshIntervalMs = interval;
                }
            }
            catch (...) {
            }
        }

        else if (key == "export_directory" && !value.empty()) {
            config.exportDirectory = value;
        }
    }

    return config;
}

bool saveConfig(const AppConfig& config) {

    std::filesystem::path path = getConfigPath();

    if (path.empty()) {
        return false;
    }

    std::error_code error;

    std::filesystem::create_directories(
        path.parent_path(),
        error
    );

    if (error) {
        return false;
    }

    std::ofstream file(path);

    if (!file.is_open()) {
        return false;
    }

    file << "refresh_interval_ms="
         << config.refreshIntervalMs << '\n';

    file << "export_directory="
         << config.exportDirectory << '\n';

    return file.good();
}
#include "process/process_manager.hpp"

#include <filesystem>
#include <algorithm>
#include <cctype>

std::vector<ProcessInfo> getAllProcesses() {

    std::vector<ProcessInfo> processes;

    std::error_code error;

    for (const auto& entry :
         std::filesystem::directory_iterator("/proc", error)) {

        std::string name = entry.path().filename().string();

        if (name.empty()) {
            continue;
        }

        bool isPID = std::all_of(
            name.begin(),
            name.end(),
            [](unsigned char c) {
                return std::isdigit(c);
            }
        );

        if (!isPID) {
            continue;
        }

        try {
            int pid = std::stoi(name);

            ProcessInfo process;

            if (readProcess(pid, process)) {
                processes.push_back(process);
            }
        }
        catch (...) {
            continue;
        }
    }

    return processes;
}

void calculateProcessUsage(
    std::vector<ProcessInfo>& current,
    const std::unordered_map<int, ProcessInfo>& previous,
    uint64_t totalCpuDiff,
    int coreCount,
    double totalMemoryKB
) {

    for (auto& process : current) {

        auto it = previous.find(process.pid);

        if (it != previous.end() &&
            process.cpuTicks >= it->second.cpuTicks &&
            totalCpuDiff > 0 &&
            coreCount > 0) {

            uint64_t processDiff =
                process.cpuTicks - it->second.cpuTicks;

            process.cpuPercent =
                (static_cast<double>(processDiff) /
                 static_cast<double>(totalCpuDiff)) * coreCount * 100.0;
        }

        if (totalMemoryKB > 0) {
            process.memoryPercent =
                (static_cast<double>(process.rssKB) / totalMemoryKB) * 100.0;
        }
    }
}
#include "process/process.hpp"

#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <unistd.h>

bool readProcess(int pid, ProcessInfo& process) {

    std::string path = "/proc/" + std::to_string(pid) + "/stat";

    std::ifstream file(path);

    if (!file.is_open()) {
        return false;
    }

    std::string line;

    if (!std::getline(file, line)) {
        return false;
    }

    size_t start = line.find('(');
    size_t end = line.rfind(')');

    if (start == std::string::npos ||
        end == std::string::npos ||
        end <= start) {
        return false;
    }

    process.pid = pid;
    process.name = line.substr(start + 1, end - start - 1);

    std::istringstream stream(line.substr(end + 1));

    std::vector<std::string> fields;
    std::string value;

    while (stream >> value) {
        fields.push_back(value);
    }

    if (fields.size() <= 21) {
        return false;
    }

    try {
        process.state = fields[0][0];
        process.ppid = std::stoi(fields[1]);

        uint64_t userTime = std::stoull(fields[11]);
        uint64_t systemTime = std::stoull(fields[12]);

        process.cpuTicks = userTime + systemTime;

        process.threads = std::stoi(fields[17]);

        long rssPages = std::stol(fields[21]);

        long pageSize = sysconf(_SC_PAGESIZE);

        if (pageSize <= 0) {
            return false;
        }

        process.rssKB =
            (rssPages * pageSize) / 1024;

        return true;
    }
    catch (...) {
        return false;
    }
}
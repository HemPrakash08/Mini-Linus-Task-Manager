#include "system/cpu.hpp"

#include <fstream>
#include <string>

CPUStats getCPUStats() {
    std::ifstream file("/proc/stat");

    CPUStats stats{0, 0};

    if (!file.is_open()) {
        return stats;
    }

    std::string label;
    uint64_t user, nice, system, idle, iowait;
    uint64_t irq, softirq, steal, guest, guestNice;

    file >> label >> user >> nice >> system >> idle
         >> iowait >> irq >> softirq >> steal
         >> guest >> guestNice;

    if (!file || label != "cpu") {
        return stats;
    }

    stats.total = user + nice + system + idle +
                  iowait + irq + softirq + steal;

    stats.idle = idle + iowait;

    return stats;
}

double getCPUUsage(const CPUStats& previous,
                   const CPUStats& current) {

    if (current.total <= previous.total ||
        current.idle < previous.idle) {
        return 0.0;
    }

    uint64_t totalDiff = current.total - previous.total;
    uint64_t idleDiff = current.idle - previous.idle;

    return (1.0 - static_cast<double>(idleDiff) /
            totalDiff) * 100.0;
}

int getCPUCoreCount() {
    std::ifstream file("/proc/cpuinfo");

    std::string line;
    int count = 0;

    while (std::getline(file, line)) {
        if (line.find("processor") == 0) {
            count++;
        }
    }

    return count;
}
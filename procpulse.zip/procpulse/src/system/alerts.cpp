#include "system/alerts.hpp"

HealthReport evaluateHealth(
    double cpuUsage,
    double memoryUsage,
    double diskUsage,
    const std::vector<ProcessInfo>& processes
) {

    HealthReport report;

    bool warning = false;
    bool critical = false;

    if (cpuUsage >= 95.0) {
        report.alerts.push_back("CRITICAL: CPU usage is above 95%.");
        critical = true;
    }
    else if (cpuUsage >= 80.0) {
        report.alerts.push_back("WARNING: CPU usage is above 80%.");
        warning = true;
    }

    if (memoryUsage >= 95.0) {
        report.alerts.push_back("CRITICAL: RAM usage is above 95%.");
        critical = true;
    }
    else if (memoryUsage >= 80.0) {
        report.alerts.push_back("WARNING: RAM usage is above 80%.");
        warning = true;
    }

    if (diskUsage >= 95.0) {
        report.alerts.push_back("CRITICAL: Disk usage is above 95%.");
        critical = true;
    }
    else if (diskUsage >= 90.0) {
        report.alerts.push_back("WARNING: Disk usage is above 90%.");
        warning = true;
    }

    for (const auto& process : processes) {

        if (process.state == 'Z') {
            report.zombieCount++;
        }
    }

    if (report.zombieCount > 0) {

        report.alerts.push_back(
            "WARNING: " +
            std::to_string(report.zombieCount) +
            " zombie process(es) detected."
        );

        warning = true;
    }

    if (critical) {
        report.healthStatus = "CRITICAL";
    }
    else if (warning) {
        report.healthStatus = "WARNING";
    }
    else {
        report.healthStatus = "HEALTHY";
    }

    return report;
}
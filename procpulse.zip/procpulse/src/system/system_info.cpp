#include "system/system_info.hpp"

#include <fstream>
#include <iomanip>
#include <sstream>

SystemInfo getSystemInfo() {
    SystemInfo info{};

    std::ifstream uptimeFile("/proc/uptime");

    if (uptimeFile.is_open()) {
        uptimeFile >> info.uptime;
    }

    std::ifstream loadFile("/proc/loadavg");

    if (loadFile.is_open()) {
        loadFile >> info.load1
                 >> info.load5
                 >> info.load15;
    }

    return info;
}

std::string formatUptime(double seconds) {
    long long totalSeconds = static_cast<long long>(seconds);

    long long days = totalSeconds / 86400;
    long long hours = (totalSeconds % 86400) / 3600;
    long long minutes = (totalSeconds % 3600) / 60;

    std::ostringstream output;

    if (days > 0) {
        output << days << " days, ";
    }

    output << hours << " hours, "
           << minutes << " minutes";

    return output.str();
}
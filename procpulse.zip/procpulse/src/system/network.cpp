#include "system/network.hpp"

#include <fstream>
#include <sstream>
#include <string>

NetworkStats getNetworkStats() {

    NetworkStats stats{};

    std::ifstream file("/proc/net/dev");

    std::string line;

    std::getline(file, line);
    std::getline(file, line);

    while (std::getline(file, line)) {

        size_t separator = line.find(':');

        if (separator == std::string::npos) {
            continue;
        }

        std::string interfaceName =
            line.substr(0, separator);

        size_t first = interfaceName.find_first_not_of(" \t");

        if (first == std::string::npos) {
            continue;
        }

        interfaceName =
            interfaceName.substr(first);

        if (interfaceName == "lo") {
            continue;
        }

        std::istringstream stream(
            line.substr(separator + 1)
        );

        uint64_t values[16]{};

        for (int i = 0; i < 16; i++) {
            if (!(stream >> values[i])) {
                break;
            }
        }

        stats.receivedBytes += values[0];
        stats.transmittedBytes += values[8];
    }

    return stats;
}
#include "system/disk.hpp"

#include <fstream>
#include <sstream>
#include <string>
#include <filesystem>
#include <sys/statvfs.h>

DiskStats getDiskStats() {

    DiskStats stats{};

    struct statvfs filesystem {};

    if (statvfs("/", &filesystem) == 0) {

        stats.totalBytes =
            static_cast<uint64_t>(filesystem.f_blocks) *
            filesystem.f_frsize;

        uint64_t availableBytes =
            static_cast<uint64_t>(filesystem.f_bavail) *
            filesystem.f_frsize;

        if (availableBytes <= stats.totalBytes) {
            stats.usedBytes =
                stats.totalBytes - availableBytes;
        }
    }

    std::ifstream file("/proc/diskstats");

    std::string line;

    while (std::getline(file, line)) {

        std::istringstream stream(line);

        int majorNumber, minorNumber;
        std::string device;

        uint64_t reads, readsMerged, sectorsRead, readTime;
        uint64_t writes, writesMerged, sectorsWritten, writeTime;

        if (!(stream >> majorNumber >> minorNumber >> device
              >> reads >> readsMerged >> sectorsRead >> readTime
              >> writes >> writesMerged >> sectorsWritten >> writeTime)) {
            continue;
        }

        if (device.find("loop") == 0 ||
            device.find("ram") == 0 ||
            device.find("zram") == 0) {
            continue;
        }

        std::string partitionPath =
            "/sys/class/block/" + device + "/partition";

        if (std::filesystem::exists(partitionPath)) {
            continue;
        }

        stats.readBytes += sectorsRead * 512ULL;
        stats.writeBytes += sectorsWritten * 512ULL;
    }

    return stats;
}
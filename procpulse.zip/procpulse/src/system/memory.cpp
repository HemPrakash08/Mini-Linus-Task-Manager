#include "system/memory.hpp"

#include <fstream>
#include <string>

MemoryStats getMemoryStats() {
    std::ifstream file("/proc/meminfo");

    MemoryStats stats{};

    std::string key;
    double value;
    std::string unit;

    while (file >> key >> value >> unit) {

        if (key == "MemTotal:") {
            stats.total = value;
        }
        else if (key == "MemAvailable:") {
            stats.available = value;
        }
        else if (key == "SwapTotal:") {
            stats.swapTotal = value;
        }
        else if (key == "SwapFree:") {
            stats.swapFree = value;
        }
    }

    stats.used = stats.total - stats.available;

    if (stats.total > 0) {
        stats.usagePercent =
            (stats.used / stats.total) * 100.0;
    }

    return stats;
}
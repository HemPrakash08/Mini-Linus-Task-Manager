#include "ui/dashboard.hpp"

int main() {

    runDashboard();

    return 0;
}
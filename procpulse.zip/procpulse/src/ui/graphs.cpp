#include "ui/graphs.hpp"

#include <ncurses.h>

#include <algorithm>
#include <cmath>
#include <string>
#include <vector>

void drawGraph(
    const std::string& title,
    const std::vector<double>& values,
    int y,
    int x,
    int width,
    int height,
    double maxValue
) {

    if (width < 15 || height < 3) {
        return;
    }

    mvaddnstr(y, x, title.c_str(), width);

    int graphHeight = height - 1;
    int graphWidth = width;

    for (int i = 0; i < graphWidth; i++) {
        mvaddch(y + height - 1, x + i, '-');
    }

    if (values.empty()) {
        mvaddnstr(
            y + 1,
            x,
            "Collecting data...",
            width
        );
        return;
    }

    double scale = maxValue > 0 ? maxValue : 1.0;

    int previousX = -1;
    int previousY = -1;

    int count = static_cast<int>(values.size());

    for (int i = 0; i < count; i++) {

        int plotX;

        if (count == 1) {
            plotX = graphWidth - 1;
        }
        else {
            plotX = static_cast<int>(
                static_cast<double>(i) *
                (graphWidth - 1) /
                (count - 1)
            );
        }

        double normalized =
            std::clamp(values[i] / scale, 0.0, 1.0);

        int plotY =
            graphHeight - 1 -
            static_cast<int>(
                normalized * (graphHeight - 1)
            );

        if (previousX >= 0) {

            int steps = std::max(
                std::abs(plotX - previousX),
                std::abs(plotY - previousY)
            );

            for (int step = 1; step < steps; step++) {

                double ratio =
                    static_cast<double>(step) / steps;

                int lineX = static_cast<int>(
                    previousX +
                    ratio * (plotX - previousX)
                );

                int lineY = static_cast<int>(
                    previousY +
                    ratio * (plotY - previousY)
                );

                if (lineX >= 0 &&
                    lineX < graphWidth &&
                    lineY >= 0 &&
                    lineY < graphHeight) {

                    mvaddch(
                        y + 1 + lineY,
                        x + lineX,
                        '.'
                    );
                }
            }
        }

        mvaddch(
            y + 1 + plotY,
            x + plotX,
            '*'
        );

        previousX = plotX;
        previousY = plotY;
    }

    mvprintw(
        y + height - 1,
        x + graphWidth - 12,
        "Max: %.1f",
        maxValue
    );
}
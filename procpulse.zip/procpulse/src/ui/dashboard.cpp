#include "ui/dashboard.hpp"
#include "ui/graphs.hpp"
#include "system/alerts.hpp"
#include "utils/config.hpp"
#include "utils/csv_export.hpp"
#include <cctype>
#include <cstdlib>
#include <limits>
#include <filesystem>
#include <stdexcept>

#include <ncurses.h>

#include <algorithm>
#include <chrono>
#include <csignal>
#include <cstdint>
#include <sstream>
#include <string>
#include <unordered_map>
#include <unistd.h>
#include <vector>

#include "system/system_monitor.hpp"
#include "system/disk.hpp"
#include "system/network.hpp"
#include "process/process_manager.hpp"

enum class SortMode {
    CPU,
    MEMORY,
    PID
};

void addHistory(
    std::vector<double>& history,
    double value
) {

    const size_t maxSamples = 60;

    history.push_back(value);

    if (history.size() > maxSamples) {
        history.erase(history.begin());
    }
}

double historyMaximum(
    const std::vector<double>& history,
    double minimum
) {

    if (history.empty()) {
        return minimum;
    }

    double maximum = *std::max_element(
        history.begin(),
        history.end()
    );

    return std::max(minimum, maximum * 1.2);
}

void drawBar(int y, int x, double percentage, int width) {

    percentage = std::max(0.0, std::min(100.0, percentage));

    int filled = static_cast<int>(
        percentage / 100.0 * width
    );

    mvaddch(y, x, '[');

    for (int i = 0; i < width; i++) {
        mvaddch(y, x + 1 + i, i < filled ? '#' : '-');
    }

    mvaddch(y, x + width + 1, ']');
}

std::string toLower(std::string value) {

    std::transform(
        value.begin(),
        value.end(),
        value.begin(),
        [](unsigned char c) {
            return static_cast<char>(std::tolower(c));
        }
    );

    return value;
}

std::vector<ProcessInfo> filterProcesses(
    const std::vector<ProcessInfo>& processes,
    const std::string& query
) {

    std::vector<ProcessInfo> result;

    std::string search = toLower(query);

    for (const auto& process : processes) {

        std::string name = toLower(process.name);
        std::string pid = std::to_string(process.pid);

        if (search.empty() ||
            name.find(search) != std::string::npos ||
            pid.find(search) != std::string::npos) {

            result.push_back(process);
        }
    }

    return result;
}

std::string formatRate(double bytesPerSecond) {

    std::ostringstream output;

    if (bytesPerSecond >= 1024.0 * 1024.0) {

        output.precision(2);
        output << std::fixed
               << bytesPerSecond / (1024.0 * 1024.0)
               << " MB/s";
    }
    else if (bytesPerSecond >= 1024.0) {

        output.precision(2);
        output << std::fixed
               << bytesPerSecond / 1024.0
               << " KB/s";
    }
    else {

        output.precision(0);
        output << std::fixed
               << bytesPerSecond
               << " B/s";
    }

    return output.str();
}

void showProcessDetails(const ProcessInfo& process) {

    int rows, cols;
    getmaxyx(stdscr, rows, cols);

    int boxWidth = std::min(60, cols - 4);
    int boxHeight = 14;

    if (boxWidth < 40 || rows < boxHeight + 2) {
        return;
    }

    int startY = std::max(1, (rows - boxHeight) / 2);
    int startX = std::max(1, (cols - boxWidth) / 2);

    WINDOW* window = newwin(
        boxHeight,
        boxWidth,
        startY,
        startX
    );

    if (!window) {
        return;
    }

    box(window, 0, 0);

    mvwprintw(window, 1, 2, "PROCESS DETAILS");

    mvwprintw(window, 3, 2, "PID: %d", process.pid);
    mvwprintw(window, 4, 2, "Parent PID: %d", process.ppid);

    mvwprintw(
        window, 5, 2,
        "Name: %.40s",
        process.name.c_str()
    );

    mvwprintw(window, 6, 2, "State: %c", process.state);
    mvwprintw(window, 7, 2, "Threads: %d", process.threads);

    mvwprintw(
        window, 8, 2,
        "CPU Usage: %.2f%%",
        process.cpuPercent
    );

    mvwprintw(
        window, 9, 2,
        "Memory Usage: %.2f%%",
        process.memoryPercent
    );

    mvwprintw(
        window, 10, 2,
        "Resident Memory: %.2f MB",
        static_cast<double>(process.rssKB) / 1024.0
    );

    mvwprintw(window, 12, 2, "Press any key to return");

    wrefresh(window);
    wgetch(window);

    delwin(window);
}

void showAlertHistory(
    const std::vector<std::string>& alerts
) {

    int rows, cols;
    getmaxyx(stdscr, rows, cols);

    int height = std::min(
        rows - 4,
        static_cast<int>(alerts.size()) + 6
    );

    int width = std::min(80, cols - 4);

    if (height < 6 || width < 30) {
        return;
    }

    int startY = (rows - height) / 2;
    int startX = (cols - width) / 2;

    WINDOW* window = newwin(
        height,
        width,
        startY,
        startX
    );

    if (!window) {
        return;
    }

    box(window, 0, 0);

    mvwprintw(window, 1, 2, "RECENT ALERT HISTORY");

    if (alerts.empty()) {
        mvwprintw(window, 3, 2, "No alerts recorded.");
    }
    else {

        int displayCount = std::min(
            static_cast<int>(alerts.size()),
            height - 4
        );

        int startIndex =
            static_cast<int>(alerts.size()) - displayCount;

        for (int i = 0; i < displayCount; i++) {

            mvwaddnstr(
                window,
                3 + i,
                2,
                alerts[startIndex + i].c_str(),
                width - 4
            );
        }
    }

    mvwprintw(
        window,
        height - 2,
        2,
        "Press any key to return"
    );

    wrefresh(window);
    wgetch(window);

    delwin(window);
}

void showSettings(AppConfig& config) {

    int rows, cols;
    getmaxyx(stdscr, rows, cols);

    int width = std::min(70, cols - 4);
    int height = 12;

    if (width < 40 || rows < height + 2) {
        return;
    }

    int startY = (rows - height) / 2;
    int startX = (cols - width) / 2;

    WINDOW* window = newwin(
        height,
        width,
        startY,
        startX
    );

    if (!window) {
        return;
    }

    box(window, 0, 0);

    mvwprintw(window, 1, 2, "PROCPULSE SETTINGS");

    mvwprintw(
        window, 3, 2,
        "Current refresh interval: %d ms",
        config.refreshIntervalMs
    );

    mvwprintw(
        window, 4, 2,
        "Current export directory:"
    );

    mvwaddnstr(
        window, 5, 2,
        config.exportDirectory.c_str(),
        width - 4
    );

    mvwprintw(
        window, 7, 2,
        "New refresh interval (500-5000 ms, 0 = keep):"
    );

    wrefresh(window);

    char intervalInput[32] = {};

    echo();
    curs_set(1);
    timeout(-1);

    int inputResult = mvwgetnstr(
        window,
        8,
        2,
        intervalInput,
        30
    );

    noecho();
    curs_set(0);

    if (inputResult == ERR) {
        delwin(window);
        return;
    }

    if (intervalInput[0] != '\0') {

        try {

            std::string input(intervalInput);

            size_t position = 0;
            int interval = std::stoi(input, &position);

            if (position != input.size()) {
                throw std::invalid_argument("Invalid interval");
            }

            if (interval == 0) {
                // Keep the existing interval.
            }
            else if (interval >= 500 && interval <= 5000) {
                config.refreshIntervalMs = interval;
            }
            else {
                mvwprintw(
                    window, 10, 2,
                    "Invalid interval. Existing value retained."
                );

                wrefresh(window);
                wgetch(window);
            }
        }
        catch (...) {

            mvwprintw(
                window, 10, 2,
                "Invalid input. Existing value retained."
            );

            wrefresh(window);
            wgetch(window);
        }
    }

    mvwprintw(
        window, 9, 2,
        "New export directory (blank = keep current):"
    );

    wrefresh(window);

    char directoryInput[512] = {};

    inputResult = mvwgetnstr(
        window,
        10,
        2,
        directoryInput,
        500
    );

    noecho();
    curs_set(0);

    if (inputResult != ERR && directoryInput[0] != '\0') {

        std::string newDirectory(directoryInput);

        std::error_code error;

        std::filesystem::create_directories(
            newDirectory,
            error
        );

        if (!error &&
            std::filesystem::is_directory(newDirectory)) {

            config.exportDirectory = newDirectory;
        }
        else {

            mvwprintw(
                window, 11, 2,
                "Directory invalid or inaccessible."
            );

            wrefresh(window);
            wgetch(window);
        }
    }

    bool saved = saveConfig(config);

    if (!saved) {
        mvwprintw(
            window, 11, 2,
            "Could not save configuration."
        );
    }
    else {
        mvwprintw(
            window, 11, 2,
            "Settings saved successfully."
        );
    }

    wrefresh(window);
    wgetch(window);

    delwin(window);
}

void runDashboard() {

    AppConfig config = loadConfig();

    initscr();

    cbreak();
    noecho();
    keypad(stdscr, TRUE);
    curs_set(0);
    timeout(config.refreshIntervalMs);

    bool running = true;

    CPUStats previousCPU = getCPUStats();

    std::vector<ProcessInfo> previousProcesses =
        getAllProcesses();

    DiskStats previousDisk = getDiskStats();
    NetworkStats previousNetwork = getNetworkStats();

    auto previousTime = std::chrono::steady_clock::now();

    int cores = getCPUCoreCount();
    int selectedIndex = 0;

    SortMode sortMode = SortMode::CPU;

    std::string searchQuery;
    std::string statusMessage = "Dashboard ready.";
    bool graphView = false;

    std::vector<double> cpuHistory;
    std::vector<double> memoryHistory;

    std::vector<double> diskReadHistory;
    std::vector<double> diskWriteHistory;

    std::vector<double> networkDownloadHistory;
    std::vector<double> networkUploadHistory;

    std::vector<std::string> alertHistory;
    std::vector<std::string> previousAlerts;

    while (running) {

        CPUStats currentCPU = getCPUStats();

        std::vector<ProcessInfo> currentProcesses =
            getAllProcesses();

        DiskStats currentDisk = getDiskStats();
        NetworkStats currentNetwork = getNetworkStats();

        auto currentTime = std::chrono::steady_clock::now();

        double elapsed =
            std::chrono::duration<double>(
                currentTime - previousTime
            ).count();

        uint64_t totalCpuDiff = 0;

        if (currentCPU.total > previousCPU.total) {
            totalCpuDiff =
                currentCPU.total - previousCPU.total;
        }

        std::unordered_map<int, ProcessInfo> previousMap;

        for (const auto& process : previousProcesses) {
            previousMap[process.pid] = process;
        }

        MemoryStats memory = getMemoryStats();

        calculateProcessUsage(
            currentProcesses,
            previousMap,
            totalCpuDiff,
            cores,
            memory.total
        );

        double cpuUsage =
            getCPUUsage(previousCPU, currentCPU);

        SystemInfo system = getSystemInfo();

        double diskReadRate = 0;
        double diskWriteRate = 0;
        double networkReceiveRate = 0;
        double networkTransmitRate = 0;

        if (elapsed > 0) {

            if (currentDisk.readBytes >= previousDisk.readBytes) {
                diskReadRate =
                    static_cast<double>(currentDisk.readBytes - previousDisk.readBytes) /
                    elapsed;
            }

            if (currentDisk.writeBytes >= previousDisk.writeBytes) {
                diskWriteRate =
                    static_cast<double>(currentDisk.writeBytes - previousDisk.writeBytes) /
                    elapsed;
            }

            if (currentNetwork.receivedBytes >= previousNetwork.receivedBytes) {
                networkReceiveRate =
                    static_cast<double>(currentNetwork.receivedBytes -
                     previousNetwork.receivedBytes) / elapsed;
            }

            if (currentNetwork.transmittedBytes >= previousNetwork.transmittedBytes) {
                networkTransmitRate =
                    static_cast<double>(currentNetwork.transmittedBytes -
                     previousNetwork.transmittedBytes) / elapsed;
            }
        }

        double diskUsage = 0.0;

        if (currentDisk.totalBytes > 0) {
            diskUsage =
                static_cast<double>(currentDisk.usedBytes) /
                static_cast<double>(currentDisk.totalBytes) * 100.0;
        }

        HealthReport health = evaluateHealth(
            cpuUsage,
            memory.usagePercent,
            diskUsage,
            currentProcesses
        );

        if (health.alerts != previousAlerts) {

            for (const auto& alert : health.alerts) {

                if (std::find(
                    previousAlerts.begin(),
                    previousAlerts.end(),
                    alert
                ) == previousAlerts.end()) {

                    alertHistory.push_back(alert);

                    if (alertHistory.size() > 10) {
                        alertHistory.erase(alertHistory.begin());
                    }
                }
            }

            previousAlerts = health.alerts;
        }

        // Record history after variables are computed
        addHistory(cpuHistory, cpuUsage);
        addHistory(memoryHistory, memory.usagePercent);

        addHistory(diskReadHistory, diskReadRate / 1024.0);
        addHistory(diskWriteHistory, diskWriteRate / 1024.0);

        addHistory(
            networkDownloadHistory,
            networkReceiveRate / 1024.0
        );

        addHistory(
            networkUploadHistory,
            networkTransmitRate / 1024.0
        );

        if (sortMode == SortMode::CPU) {

            std::sort(
                currentProcesses.begin(),
                currentProcesses.end(),
                [](const ProcessInfo& a, const ProcessInfo& b) {
                    return a.cpuPercent > b.cpuPercent;
                }
            );

        }
        else if (sortMode == SortMode::MEMORY) {

            std::sort(
                currentProcesses.begin(),
                currentProcesses.end(),
                [](const ProcessInfo& a, const ProcessInfo& b) {
                    return a.memoryPercent > b.memoryPercent;
                }
            );

        }
        else {

            std::sort(
                currentProcesses.begin(),
                currentProcesses.end(),
                [](const ProcessInfo& a, const ProcessInfo& b) {
                    return a.pid < b.pid;
                }
            );
        }

        std::vector<ProcessInfo> visibleProcesses =
            filterProcesses(currentProcesses, searchQuery);

        if (visibleProcesses.empty()) {
            selectedIndex = 0;
        }
        else {
            selectedIndex = std::min(
                selectedIndex,
                static_cast<int>(visibleProcesses.size()) - 1
            );
        }

        int rows, cols;
        getmaxyx(stdscr, rows, cols);

        erase();

        if (rows < 30 || cols < 80) {

            mvprintw(
                2, 2,
                "Terminal too small. Minimum recommended: 80 x 30."
            );

            mvprintw(4, 2, "Press Q to quit.");

        }
        else {

            std::string title =
                "PROCPULSE - LINUX SYSTEM MONITOR";

            attron(A_BOLD);

            mvprintw(
                1,
                (cols - static_cast<int>(title.length())) / 2,
                "%s",
                title.c_str()
            );

            attroff(A_BOLD);

            mvhline(2, 0, '-', cols);

            attron(A_BOLD);
            mvprintw(4, 3, "CPU INFORMATION");
            attroff(A_BOLD);

            mvprintw(
                5, 3,
                "CPU Usage: %6.2f%%    Logical Cores: %d",
                cpuUsage,
                cores
            );

            drawBar(6, 3, cpuUsage, 35);

            attron(A_BOLD);
            mvprintw(8, 3, "MEMORY INFORMATION");
            attroff(A_BOLD);

            mvprintw(
                9, 3,
                "RAM Usage: %6.2f%%    Used: %.2f GB / %.2f GB",
                memory.usagePercent,
                memory.used / (1024.0 * 1024.0),
                memory.total / (1024.0 * 1024.0)
            );

            drawBar(10, 3, memory.usagePercent, 35);

            attron(A_BOLD);
            mvprintw(12, 3, "SYSTEM INFORMATION");
            attroff(A_BOLD);

            mvprintw(
                13, 3,
                "Uptime: %s    Load: %.2f, %.2f, %.2f",
                formatUptime(system.uptime).c_str(),
                system.load1,
                system.load5,
                system.load15
            );

            attron(A_BOLD);
            mvprintw(15, 3, "DISK INFORMATION");
            attroff(A_BOLD);

            mvprintw(
                16, 3,
                "Root Usage: %.2f%%   Used: %.2f GB / %.2f GB",
                diskUsage,
                static_cast<double>(currentDisk.usedBytes) / (1024.0 * 1024.0 * 1024.0),
                static_cast<double>(currentDisk.totalBytes) / (1024.0 * 1024.0 * 1024.0)
            );

            mvprintw(
                17, 3,
                "Read: %s   Write: %s",
                formatRate(diskReadRate).c_str(),
                formatRate(diskWriteRate).c_str()
            );

            attron(A_BOLD);
            mvprintw(19, 3, "NETWORK INFORMATION");
            attroff(A_BOLD);

            mvprintw(
                20, 3,
                "Download: %s   Upload: %s",
                formatRate(networkReceiveRate).c_str(),
                formatRate(networkTransmitRate).c_str()
            );

            attron(A_BOLD);
            mvprintw(21, 3, "SYSTEM HEALTH");
            attroff(A_BOLD);

            mvprintw(
                21, 20,
                "Status: %s    Zombie Processes: %d    Active Alerts: %zu",
                health.healthStatus.c_str(),
                health.zombieCount,
                health.alerts.size()
            );

            if (!graphView) {

                std::string alertSummary = health.alerts.empty()
                    ? "No active alerts."
                    : health.alerts.front();

                mvprintw(
                    22, 3,
                    "Alert: %s",
                    alertSummary.substr(0, cols - 12).c_str()
                );

                attron(A_BOLD);
                mvprintw(23, 3, "PROCESS INFORMATION");
                attroff(A_BOLD);

                mvprintw(
                    24, 3,
                    "Processes: %zu   Sort: %s   Search: %s",
                    visibleProcesses.size(),
                    sortMode == SortMode::CPU ? "CPU" :
                    sortMode == SortMode::MEMORY ? "MEMORY" : "PID",
                    searchQuery.empty() ? "OFF" : searchQuery.c_str()
                );

                mvprintw(
                    25, 2,
                    "%-8s %-22s %8s %8s %8s %8s",
                    "PID",
                    "PROCESS",
                    "CPU%",
                    "MEM%",
                    "STATE",
                    "THREADS"
                );

                mvhline(26, 2, '-', cols - 4);

                int displayRows = std::max(0, rows - 30);

                int startIndex = 0;

                if (selectedIndex >= displayRows && displayRows > 0) {
                    startIndex = selectedIndex - displayRows + 1;
                }

                for (
                    int i = startIndex;
                    i < static_cast<int>(visibleProcesses.size()) &&
                    i < startIndex + displayRows;
                    i++
                ) {

                    const auto& process = visibleProcesses[i];

                    if (i == selectedIndex) {
                        attron(A_REVERSE);
                    }

                    mvprintw(
                        27 + i - startIndex,
                        2,
                        "%-8d %-22.22s %7.2f%% %7.2f%% %8c %8d",
                        process.pid,
                        process.name.c_str(),
                        process.cpuPercent,
                        process.memoryPercent,
                        process.state,
                        process.threads
                    );

                    if (i == selectedIndex) {
                        attroff(A_REVERSE);
                    }
                }

            }
            else {

                attron(A_BOLD);
                mvprintw(22, 3, "PERFORMANCE HISTORY - LAST 60 SAMPLES");
                attroff(A_BOLD);

                if (rows < 40 || cols < 100) {

                    mvprintw(
                        25, 3,
                        "Graph view requires a terminal of at least 100 x 40."
                    );

                }
                else {

                    int graphWidth = (cols - 10) / 2;
                    int secondX = 5 + graphWidth;

                    drawGraph(
                        "CPU USAGE (%)",
                        cpuHistory,
                        23, 3,
                        graphWidth, 4,
                        historyMaximum(cpuHistory, 1.0)
                    );

                    drawGraph(
                        "MEMORY USAGE (%)",
                        memoryHistory,
                        23, secondX,
                        graphWidth, 4,
                        100.0
                    );

                    drawGraph(
                        "DISK READ (KB/s)",
                        diskReadHistory,
                        28, 3,
                        graphWidth, 4,
                        historyMaximum(diskReadHistory, 1.0)
                    );

                    drawGraph(
                        "DISK WRITE (KB/s)",
                        diskWriteHistory,
                        28, secondX,
                        graphWidth, 4,
                        historyMaximum(diskWriteHistory, 1.0)
                    );

                    drawGraph(
                        "NETWORK DOWNLOAD (KB/s)",
                        networkDownloadHistory,
                        33, 3,
                        graphWidth, 4,
                        historyMaximum(networkDownloadHistory, 1.0)
                    );

                    drawGraph(
                        "NETWORK UPLOAD (KB/s)",
                        networkUploadHistory,
                        33, secondX,
                        graphWidth, 4,
                        historyMaximum(networkUploadHistory, 1.0)
                    );
                }
            }

            mvhline(rows - 2, 0, '-', cols);

            mvprintw(
                rows - 3, 2,
                "%s",
                statusMessage.substr(0, cols - 5).c_str()
            );

            mvprintw(
                rows - 1, 2,
                "UP/DOWN Select | C CPU | M RAM | P PID | / Search | A All | G Graphs | H Alerts | E Export CSV | S Settings | ENTER Details | K Kill | Q Quit"
            );
        }

        refresh();

        previousCPU = currentCPU;
        previousProcesses = currentProcesses;

        previousDisk = currentDisk;
        previousNetwork = currentNetwork;
        previousTime = currentTime;

        timeout(config.refreshIntervalMs);
        int key = getch();

        if (key == ERR) {
            continue;
        }

        if (key == 'q' || key == 'Q') {
            running = false;
        }

        else if (key == KEY_UP) {

            if (selectedIndex > 0) {
                selectedIndex--;
            }
        }

        else if (key == KEY_DOWN) {

            if (selectedIndex + 1 <
                static_cast<int>(visibleProcesses.size())) {
                selectedIndex++;
            }
        }

        else if (key == 'c' || key == 'C') {

            sortMode = SortMode::CPU;
            selectedIndex = 0;
            statusMessage = "Sorted by CPU usage.";
        }

        else if (key == 'm' || key == 'M') {

            sortMode = SortMode::MEMORY;
            selectedIndex = 0;
            statusMessage = "Sorted by memory usage.";
        }

        else if (key == 'p' || key == 'P') {

            sortMode = SortMode::PID;
            selectedIndex = 0;
            statusMessage = "Sorted by PID.";
        }

        else if (key == 'g' || key == 'G') {

            graphView = !graphView;

            statusMessage = graphView
                ? "Performance history enabled."
                : "Process table restored.";
        }

        else if (key == 'h' || key == 'H') {

            showAlertHistory(alertHistory);
        }

        else if (key == 'e' || key == 'E') {

            std::string outputPath;
            std::string errorMessage;

            bool success = exportProcessesCSV(
                currentProcesses,
                config.exportDirectory,
                outputPath,
                errorMessage
            );

            if (success) {

                statusMessage =
                    "CSV exported: " + outputPath;
            }
            else {

                statusMessage =
                    "CSV export failed: " + errorMessage;
            }
        }

        else if (key == 's' || key == 'S') {

            showSettings(config);

            statusMessage = "Settings updated.";
        }

        else if (key == '/') {

            char input[128] = {};

            mvprintw(
                rows - 3, 2,
                "Search process name or PID: "
            );

            clrtoeol();

            echo();
            curs_set(1);
            timeout(-1);

            getnstr(input, 127);

            noecho();
            curs_set(0);
            timeout(config.refreshIntervalMs);

            searchQuery = input;
            selectedIndex = 0;

            statusMessage = searchQuery.empty()
                ? "Search cleared."
                : "Search filter applied.";
        }

        else if (key == 'a' || key == 'A' || key == 27) {

            searchQuery.clear();
            selectedIndex = 0;
            statusMessage = "Showing all processes.";
        }

        else if (
            key == 10 ||
            key == 13 ||
            key == KEY_ENTER
        ) {

            if (!visibleProcesses.empty()) {
                showProcessDetails(
                    visibleProcesses[selectedIndex]
                );
            }
        }

        else if (key == 'k' || key == 'K') {

            if (visibleProcesses.empty()) {
                statusMessage = "No process selected.";
                continue;
            }

            const auto& process =
                visibleProcesses[selectedIndex];

            if (process.pid <= 1 || process.pid == getpid()) {

                statusMessage =
                    "Protected process. Termination blocked.";

                continue;
            }

            int selectedPID = process.pid;

            erase();

            mvprintw(
                2, 2,
                "Terminate process %s (PID %d)?",
                process.name.c_str(),
                selectedPID
            );

            mvprintw(
                4, 2,
                "Press Y to confirm or any other key to cancel."
            );

            refresh();

            timeout(-1);
            int confirmation = getch();
            timeout(config.refreshIntervalMs);

            if (confirmation == 'y' || confirmation == 'Y') {

                if (kill(selectedPID, SIGTERM) == 0) {

                    searchQuery.clear();
                    selectedIndex = 0;

                    statusMessage =
                        "SIGTERM sent to PID " +
                        std::to_string(selectedPID) +
                        ". Showing all processes.";

                }
                else {

                    statusMessage =
                        "Unable to terminate PID " +
                        std::to_string(selectedPID);
                }
            }
            else {

                statusMessage = "Termination cancelled.";
            }
        }
    }

    endwin();
}
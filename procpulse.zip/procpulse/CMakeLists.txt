cmake_minimum_required(VERSION 3.16)

project(ProcPulse)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

if(CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
    add_compile_options(
        -Wall
        -Wextra
        -Wpedantic
        -Wshadow
        -Wconversion
    )
endif()

find_package(Curses REQUIRED)

include_directories(include)

add_executable(procpulse
    src/main.cpp

    src/system/cpu.cpp
    src/system/memory.cpp
    src/system/system_info.cpp
    src/system/disk.cpp
    src/system/network.cpp
    src/system/alerts.cpp

    src/process/process.cpp
    src/process/process_manager.cpp

    src/ui/dashboard.cpp
    src/ui/graphs.cpp

    src/utils/config.cpp
    src/utils/csv_export.cpp
)

target_include_directories(procpulse PRIVATE
    ${CURSES_INCLUDE_DIRS}
)

target_link_libraries(procpulse PRIVATE
    ${CURSES_LIBRARIES}
)